## Install vala

## Download git go-for-it realease
https://github.com/mank319/Go-For-It/releases

## Extract this realease

## Enter in the folder

## Compile
mkdir b
cd b

cmake -DCMAKE_INSTALL_PREFIX=/usr .. -DAPP_SYSTEM_NAME:STRING="go-for-it"

make

make install DESTDIR="../../go-for-it-VERSION-x86_64-1_JB/"

## Get install/slack-desc from old version

## Make the package
cd ../../go-for-it-VERSION-x86_64-1_JB/
su
makepkg ../go-for-it-VERSION-x86_64-1_JB.txz

## Tips - You can set a "special application setting" for Go-For-It
    Right click on window border
        -> More Actions
            -> Special Application Settings

    ## Hide aplication from taskbar
    -> Arrangement & Access tab
        -> Skip taskbar - Force - Yes

    ## Hide aplication windows border
    -> Sppearance & Fixes
        -> No titlebar and frame -  Force - Yes

    ## You can change this later
        System Settings
            -> Window Behavior
                -> Window Rules
