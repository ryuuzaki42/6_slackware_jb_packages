#!/bin/bash
#
# Autor= João Batista Ribeiro
# Bugs, Agradecimentos, Críticas "construtivas"
# Mande me um e-mail. Ficarei Grato!
# e-mail: joao42lbatista@gmail.com
#
# Este programa é um software livre; você pode redistribui-lo e/ou
# modifica-lo dentro dos termos da Licença Pública Geral GNU como
# publicada pela Fundação do Software Livre (FSF); na versão 2 da
# Licença, ou (na sua opinião) qualquer versão.
#
# Este programa é distribuído na esperança que possa ser útil,
# mas SEM NENHUMA GARANTIA; sem uma garantia implícita de ADEQUAÇÃO a
# qualquer MERCADO ou APLICAÇÃO EM PARTICULAR.
#
# Veja a Licença Pública Geral GNU para mais detalhes.
# Você deve ter recebido uma cópia da Licença Pública Geral GNU
# junto com este programa, se não, escreva para a Fundação do Software
#
# Livre(FSF) Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
#
# Script: Script to build a Slackware package of Go-For-It
#
# Last update: 09/09/2019
#

## Install vala before build

## Download git go-for-it realease
# https://github.com/mank319/Go-For-It/releases

echo -e "\\n# Script to build a Slackware package of Go-For-It (without skins and themes) #\\n"

if [ "$USER" != "root" ]; then
    echo -e "\\nNeed to be superuser (root)\\nExiting\\n"
else
    progName="go-for-it"
    version="1.8.0"
    arch=$(arch)
    tag="1_JB"

    folderlocal=$(pwd)
    folderProg="$folderlocal/Go-For-It-$version/"

    rm -r $folderProg

    set -e

    ## Extract this realease
    tar xvf $folderlocal/"Go-For-It-$version.tar.gz"
    cd $folderProg

    ## Compile
    mkdir b
    cd b

    cmake -DCMAKE_INSTALL_PREFIX=/usr .. -DAPP_SYSTEM_NAME:STRING="go-for-it"

    make

    make install DESTDIR="../../go-for-it-$version-$arch-$tag/"

    ## Get install/slack-desc from old version
    mkdir -p ../../go-for-it-$version-$arch-$tag/install
    cat $folderlocal/slack-desc > ../../go-for-it-$version-$arch-$tag/install/slack-desc

    ## Make the package
    cd ../../go-for-it-$version-$arch-$tag/
    /sbin/makepkg -l y -c n ../go-for-it-$version-$arch-$tag.txz

    cd ..
    rm -r go-for-it-$version-$arch-$tag/
    rm -r $folderProg
fi
